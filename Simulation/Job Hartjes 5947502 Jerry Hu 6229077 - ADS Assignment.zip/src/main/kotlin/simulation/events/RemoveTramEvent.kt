package simulation.events

import simulation.interfaces.Event

class RemoveTramEvent(override var time: Int) : Event