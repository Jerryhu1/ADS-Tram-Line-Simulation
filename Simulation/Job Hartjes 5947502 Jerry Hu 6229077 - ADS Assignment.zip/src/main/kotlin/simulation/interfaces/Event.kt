package simulation.interfaces

interface Event {

    var time: Int // The time at which this Event is scheduled to occur

}